"""Create Colab notebook and ZIP. No API calls."""
from pathlib import Path
import json,zipfile
ROOT=Path(__file__).parent
cells=[]
def md(s): cells.append(dict(cell_type='markdown',metadata={},source=s.splitlines(True)))
def code(s): cells.append(dict(cell_type='code',metadata={},source=s.splitlines(True),execution_count=None,outputs=[]))
md('''# Context compilation — first-paper experiments v0.4
v0.3 is preserved as a preliminary check. v0.4 freezes its core and adds repeated trials, independent outcome audits, ablations, budget sweeps and paired statistics.
**CPU is sufficient. The pretrained encoder is included. No API requests occur until RUN_API=True.**
Start with the pilot. Do not launch the large test schedule before analysing development results and freezing the protocol.''')
md('## 1. Upload the original v0.4 ZIP')
code('''from google.colab import files
from pathlib import Path
import io, os, zipfile, json, subprocess, sys, shutil
uploaded=files.upload()
names=[n for n in uploaded if n.endswith('.zip')]
assert len(names)==1, 'Upload one package ZIP.'
dest=Path('/content/context_v04_package'); dest.mkdir(exist_ok=True)
with zipfile.ZipFile(io.BytesIO(uploaded[names[0]])) as z:
    for m in z.infolist():
        assert (dest/m.filename).resolve().is_relative_to(dest.resolve()), 'Unsafe ZIP path'
    z.extractall(dest)
os.chdir(dest/'context_engine_v04')
print('Package ready')''')
md('## 2. Install dependencies and run offline regression tests')
code('''%pip -q install -r requirements.txt
subprocess.run([sys.executable,'-m','unittest','-v','test_benchmark'],check=True)
subprocess.run([sys.executable,'-m','unittest','discover','-s','core','-p','test_context.py','-v'],check=True)''')
md('## 3. Choose the experiment\nKeep pilot and SWEEP=False for your first run. A sweep, a different stage, or changed settings requires a NEW run folder.')
code('''from benchmark import protocol, schedule, prepare, run
STAGE='pilot'  # pilot / development / test
SWEEP=False
P=protocol(STAGE, sweep=SWEEP)
RUN_NAME='paper_v04_pilot_01'
print(json.dumps(P,indent=2))
print('Scheduled episodes:',len(schedule(P)))
print('Maximum calls:',P['max_calls'])
print('Estimated spend guard (not guaranteed billing cap): $',P['budget_usd'])''')
md('## 4. Mount Drive and load the supplied visual checkpoint')
code('''from google.colab import drive
drive.mount('/content/drive')
assert RUN_NAME and all(c.isalnum() or c in '_-' for c in RUN_NAME)
RUN_DIR=Path('/content/drive/MyDrive/ContextEngineRuns')/RUN_NAME
RUN_DIR.mkdir(parents=True,exist_ok=True)
from vision import Encoder
VISION=RUN_DIR/'vision.pt'
if not VISION.exists():
    shutil.copy2('artifacts/vision.pt',VISION)
    shutil.copy2('artifacts/vision.pt.json',str(VISION)+'.json')
encoder=Encoder(VISION)
prepare(RUN_DIR,P,encoder)
(RUN_DIR/'environment.txt').write_text(subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True))
print('Protocol locked and checkpoints ready:',RUN_DIR)''')
md('## 5. Free neural-perception and projection diagnostic\nThese are reference-policy results, not LLM results.')
code('''import tiktoken
from diagnostics import diagnose
encoding=tiktoken.encoding_for_model(P['model'])
def count_tokens(s): return len(encoding.encode(s))
check=diagnose(encoder,count_tokens,RUN_DIR/'REFERENCE_DIAGNOSTICS.json')
print(check)
assert check['successes']==check['episodes']
assert check['projection_action_agreement'] and check['budget_overflows']==0''')
md('## 6. Read the preliminary v0.3 results\nThese are development evidence only. They are not pooled into this experiment.')
code('''print(Path('precheck/PRECHECK.md').read_text())''')
md('## 7. Load your OpenAI key\nColab left sidebar → key icon → OPENAI_API_KEY → Value → enable Notebook access. Do not paste the key into code.')
code('''from google.colab import userdata
from openai import OpenAI
key=userdata.get('OPENAI_API_KEY')
assert key and key.strip(), 'Colab secret is empty.'
client=OpenAI(api_key=key.strip(),max_retries=0,timeout=60.0)
del key
print('Client ready. No paid calls made.')''')
md('''## 8. Run paid experiment
Default pilot: 112 episodes, maximum 672 API calls. Actual calls depend on trajectories.
Repetitions use separate calls; resuming completed jobs reuses caches. Pending requests stop the run for billing-state review. See README.''')
code('''RUN_API=False
if RUN_API:
    result=run(RUN_DIR,P,client,encoder,count_tokens)
    print(result)
    print((RUN_DIR/'REPORT.md').read_text())
else:
    print('Set RUN_API=True when ready to begin paid evaluation.')''')
md('## 9. Review and download the results\nThe small pilot has no confidence intervals because it contains only one scenario per case. Development/test schedules support the paired analysis.')
code('''from analysis import analyse
from IPython.display import display, Image
result=analyse(RUN_DIR)
print(result)
if (RUN_DIR/'results.png').exists(): display(Image(filename=str(RUN_DIR/'results.png')))
archive=shutil.make_archive('/content/context_v04_results','zip',RUN_DIR)
files.download(archive)''')
for i,c in enumerate(cells): c['id']=f'cell-{i:02d}'
nb=dict(cells=cells,metadata=dict(kernelspec=dict(display_name='Python 3',language='python',name='python3'),
        language_info=dict(name='python')),nbformat=4,nbformat_minor=5)
(ROOT/'First_Paper_Experiments_v04.ipynb').write_text(json.dumps(nb,indent=2))
with zipfile.ZipFile(ROOT.parent/'Context_Compiler_First_Paper_v0_4.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:
            z.write(p,Path('context_engine_v04')/p.relative_to(ROOT))
print('Built Context_Compiler_First_Paper_v0_4.zip')
