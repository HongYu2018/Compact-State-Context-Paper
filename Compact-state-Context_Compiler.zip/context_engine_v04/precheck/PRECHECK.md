# v0.3 preliminary experiment — retained as development evidence

Original archive SHA-256: 066401539fc14ca090af3361263c964b9c6384beead904107da3665748127dbd

| Method | Physical successes | Independently evidence-supported successes |
|---|---:|---:|
| full_history | 6/8 | 5/8 |
| full_state | 8/8 | 8/8 |
| capsule | 7/8 | 7/8 |
| full_state_verified | 8/8 | 8/8 |
| capsule_verified | 8/8 | 8/8 |

40 episodes; 73 API responses; estimated cost $0.0337988 at recorded prices.
The full-history conflict case physically succeeded but lacked resolved evidence. Its supported-success score is lower.
Independent retrospective audit uses the v0.4 evaluator; original files are preserved unchanged.
No new API calls. Do not pool these outcomes with the fresh v0.4 schedules.