"""Independent evidence audit. Does NOT import State.belief, facts, compiler or verify.
Criterion is support in the agent-accessible evidence pool, not proof that cited text entails the action.
"""

def supported(snapshot,action):
    typ,slot=action['type'],action['slot']
    if typ not in ('move','defer'): return True,'no commitment'
    raw=list(snapshot['G']['claims'].values()); now=snapshot['T']['now']
    public=[c for c in raw if c['permission']=='agent' and c['time']<=now]
    goals=[c for c in public if c['predicate']=='goal']
    if not goals: return False,'missing_goal'
    goal=max(goals,key=lambda c:(c['time'],c['id']))['value']
    obj=f'slot{slot}'
    colors=[c for c in public if c['entity']==obj and c['predicate']=='color']
    latest={}
    for c in colors:
        if c['source'] not in latest or c['time']>=latest[c['source']]['time']: latest[c['source']]=c
    colors=[c for c in latest.values() if now-c['time']<=c['ttl']]
    if not colors or any(c['value']!=goal or c['confidence']<.85 for c in colors):
        return False,'identity_not_supported'
    invalid=max([c['time'] for c in public if c['entity']==obj and c['predicate']=='payload_changed']+[-1])
    readings=[c for c in public if c['entity']==obj and c['predicate']=='mass']
    by_source={}
    for c in readings:
        if c['source'] not in by_source or c['time']>=by_source[c['source']]['time']: by_source[c['source']]=c
    usable=[c for c in by_source.values() if now-c['time']<=c['ttl'] and c['time']>invalid]
    tool_times=[c['time'] for c in usable if c['source']=='tool_scale']
    if tool_times: usable=[c for c in usable if c['time']>=max(tool_times)]
    if not usable: return False,'mass_missing_stale_or_invalidated'
    if len({c['value'] for c in usable})>1: return False,'mass_conflict'
    if any(c['confidence']<.85 for c in usable): return False,'mass_uncertain'
    if typ=='move' and any(c['value']+c['uncertainty']>3 for c in usable):
        return False,'capacity_not_supported'
    if typ=='defer' and any(c['value']-c['uncertainty']<=3 for c in usable):
        return False,'overload_not_supported'
    return True,'supported'

def episode_audit(episode):
    # Terminal snapshot retains exactly the evidence available at terminal proposal.
    # No later observation enters this snapshot; scoring excludes warm feedback.
    trace=episode['trace']; terminal=next((t for t in reversed(trace) if t.get('outcome',{}).get('done')),None)
    if terminal is None: return dict(supported_success=False,terminal_supported=False,audit_reason='no_terminal_action')
    support,reason=supported(episode['state'],terminal['action'])
    return dict(supported_success=bool(episode['success'] and support),terminal_supported=support,audit_reason=reason)
