# Validation and provenance

The package contains 22 passing offline regression tests: 15 frozen-core tests and 7 benchmark/evaluator tests. They cover state updates, conflicts, freshness, permissions, task projection, neural-evidence pointers, action verification, mocked SDK serialization, cache safety, protocol locks, balanced schedules, distinct repetition identities, independent evidence auditing, paired cluster calculations, shared cost/call limits, partial reporting and resume.

The original v0.3 result archive is included unchanged, with its SHA-256 in precheck/PRECHECK.md. Its retrospective independent support audit is clearly separated from its original scores. The visual checkpoint is copied from the validated v0.3 build; no new model training is represented as a new experiment. The original 80-episode reference-policy diagnostic is included and can be rerun in Colab.

No live API calls were made for v0.4 during implementation. Mock responses used for tests are not performance results. No v0.4 superiority claim or fabricated LLM evaluation report is bundled. Notebook/source syntax and ZIP integrity are validated at packaging. Colab credentials, Drive authorisation and model access require the user's run.

The method core is frozen except for runner orchestration instrumentation. Benchmark support scoring is separately implemented from agent inference/verification, but both follow the same published domain assumptions. This does not replace independent domain review of those assumptions.
