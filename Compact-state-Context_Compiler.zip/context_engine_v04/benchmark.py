"""Frozen-core benchmark orchestration. No paid requests until run() is called."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'core'))
import json,random,hashlib,platform,importlib.metadata
from runner import run as core_run,config as core_config
from context import hashof
from transport import save_json
from world import CASES

CONDITIONS=[{'name':n,'method':n,'budget':850} for n in
 ['full_history','full_state','capsule','full_state_verified','capsule_verified',
  'capsule_no_temporal','capsule_no_conflict']]

def protocol(stage='pilot',sweep=False):
    sizes={'pilot':(8,2,80000,5.),'development':(80,3,81000,20.),'test':(400,3,90000,80.)}
    n,repeats,offset,dollars=sizes[stage]
    conditions=[dict(x) for x in CONDITIONS]
    if sweep:
        conditions=[{'name':'full_state','method':'full_state','budget':850}]+[
          {'name':f'capsule_b{b}','method':'capsule','budget':b} for b in [200,300,450,650,850]]
    return dict(version='0.4.0',stage=stage,n_scenarios=n,repeats=repeats,offset=offset,
       order_seed=1742,conditions=conditions,model='gpt-4.1-mini-2025-04-14',max_steps=6,
       max_output_tokens=240,max_calls=n*repeats*len(conditions)*6,budget_usd=dollars,
       input_per_million=.4,cached_per_million=.1,output_per_million=1.6)

def schedule(p):
    jobs=[]; rng=random.Random(p['order_seed'])
    for r in range(p['repeats']):
        scenarios=list(range(p['n_scenarios'])); rng.shuffle(scenarios)
        for i in scenarios:
            conditions=[dict(x) for x in p['conditions']]; rng.shuffle(conditions)
            for c in conditions:
                jobs.append(dict(id=f's{i:04d}_r{r:02d}_{c["name"]}',scenario=i,
                    seed=p['offset']+i,case=CASES[i%len(CASES)],repeat=r,**c))
    return jobs

def sources():
    root=Path(__file__).parent
    return {str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest()
            for x in root.rglob('*.py') if '__pycache__' not in x.parts}

def prepare(root,p,encoder):
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    lock={'protocol':p,'sources':sources(),'vision_hash':encoder.model_hash,'jobs':schedule(p)}
    target=root/'protocol_lock.json'
    if target.exists() and json.loads(target.read_text())!=lock:
        raise ValueError('Protocol, source or vision checkpoint changed. Use a NEW run folder.')
    save_json(target,lock)
    return lock

def run(root,p,client,encoder,count):
    root=Path(root); lock=prepare(root,p,encoder)
    for k,job in enumerate(lock['jobs']):
        folder=root/'jobs'/job['id']; cfg=core_config()
        cfg.update({key:p[key] for key in ['model','max_steps','max_output_tokens','max_calls','budget_usd',
                  'input_per_million','cached_per_million','output_per_million']})
        cfg.update(episodes=1,seed=job['seed'],scenario_case=job['case'],methods=[job['method']],
            capsule_tokens=job['budget'],job_id=job['id'],shared_cache=str((root/'api_cache').resolve()))
        complete=folder/'episodes'/f'0000_{job["method"]}.json'
        if complete.exists(): continue
        print(f'Job {k+1}/{len(lock["jobs"])}: {job["id"]}',flush=True)
        core_run(folder,cfg,client,encoder,count)
        if not complete.exists():
            print('Stopped before completing this job. Completed calls preserved; see pending/cache or cost guard.')
            break
    from analysis import analyse
    return analyse(root)
