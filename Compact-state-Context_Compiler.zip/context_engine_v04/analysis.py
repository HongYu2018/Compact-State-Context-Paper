"""Paired case-stratified scenario-cluster bootstrap. Repeats are not independent scenarios."""
import csv,json,math
from pathlib import Path
import numpy as np
from evaluator import episode_audit

def write_csv(path,rows):
    if not rows: return
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def paired_interval(records,a,b,metric,draws=2000):
    groups={}
    for r in records:
        if r['condition'] in [a,b]: groups.setdefault((r['case'],r['scenario']),{}).setdefault(r['condition'],[]).append(r[metric])
    strata={}
    for (case,scenario),g in groups.items():
        if a in g and b in g:
            strata.setdefault(case,[]).append(float(np.mean(g[b])-np.mean(g[a])))
    if not strata: return None
    # With one scenario per stratum, a bootstrap cannot estimate scenario variability.
    enough=all(len(x)>=2 for x in strata.values())
    deltas=[v for vs in strata.values() for v in vs]
    mean=float(np.mean(deltas))
    if not enough: return dict(contrast=f'{b} minus {a}',metric=metric,delta=mean,low='',high='',n_scenarios=len(deltas),status='insufficient_scenarios_per_case')
    rng=np.random.default_rng(281); boot=np.zeros(draws)
    for values in strata.values():
        x=np.asarray(values); boot+=rng.choice(x,(draws,len(x)),replace=True).sum(axis=1)
    boot/=len(deltas)
    return dict(contrast=f'{b} minus {a}',metric=metric,delta=mean,low=float(np.quantile(boot,.025)),
                high=float(np.quantile(boot,.975)),n_scenarios=len(deltas),status='paired_stratified_cluster_bootstrap')

def analyse(root):
    root=Path(root); lock=json.loads((root/'protocol_lock.json').read_text()); rows=[]
    for job in lock['jobs']:
        path=root/'jobs'/job['id']/'episodes'/f'0000_{job["method"]}.json'
        if not path.exists(): continue
        e=json.loads(path.read_text()); ts=e['trace']; audit=episode_audit(e)
        rows.append(dict(job_id=job['id'],scenario=job['scenario'],case=job['case'],repeat=job['repeat'],
          condition=job['name'],budget=job['budget'],success=int(e['success']),
          supported_success=int(audit['supported_success']),audit_reason=audit['audit_reason'],
          violation=int(e['violation']),unsafe_proposals=sum(t.get('proposed_capacity_violation',False) for t in ts),
          blocks=sum(t.get('blocked',False) for t in ts),calls=len(ts),
          tokens=sum(t['input_tokens']+t['output_tokens'] for t in ts),
          cost=sum(t['estimated_usd'] for t in ts),api_seconds=sum(t['latency_s'] for t in ts),
          local_seconds=sum(t['compile_perception_seconds'] for t in ts),
          budget_failure=int(e['failure']=='context_budget_insufficient'),failure=e['failure']))
    write_csv(root/'episodes_audited.csv',rows)
    summary=[]
    for c in lock['protocol']['conditions']:
        rs=[r for r in rows if r['condition']==c['name']]; n=len(rs)
        if not n: continue
        successes=sum(r['supported_success'] for r in rs); tokens=sum(r['tokens'] for r in rs)
        summary.append(dict(condition=c['name'],completed=n,planned=lock['protocol']['n_scenarios']*lock['protocol']['repeats'],
          success_rate=sum(r['success'] for r in rs)/n,supported_success_rate=successes/n,
          violation_rate=sum(r['violation'] for r in rs)/n,total_tokens=tokens,
          tokens_per_supported_success=tokens/successes if successes else '',
          mean_tokens=tokens/n,estimated_usd=sum(r['cost'] for r in rs),
          budget_failures=sum(r['budget_failure'] for r in rs)))
    write_csv(root/'summary.csv',summary)
    complete=len(rows)==len(lock['jobs']); intervals=[]
    names=[x['name'] for x in lock['protocol']['conditions']]
    comparisons=[('full_state','capsule'),('full_state_verified','capsule_verified'),
       ('capsule','capsule_no_temporal'),('capsule','capsule_no_conflict')]
    comparisons += [('full_state',n) for n in names if n.startswith('capsule_b')]
    if complete:
        for a,b in comparisons:
            if a in names and b in names:
                for metric in ['supported_success','success','violation','tokens','api_seconds']:
                    x=paired_interval(rows,a,b,metric)
                    if x: intervals.append(x)
    write_csv(root/'paired_intervals.csv',intervals)
    ledger=[json.loads(p.read_text()) for p in (root/'api_cache').glob('*.json')]
    account={'attempts':len(ledger),'pending':sum(x['status']=='pending' for x in ledger),
             'estimated_usd':sum(x.get('estimated_usd',0) for x in ledger)}
    (root/'accounting.json').write_text(json.dumps(account,indent=2))
    report=['# First-paper experiment report','',f'Status: {"COMPLETE" if complete else "PARTIAL — no comparative confidence intervals"}.',
      f'Completed {len(rows)} of {len(lock["jobs"])} scheduled episodes.',
      '', '| Condition | Physical success | Supported success | Violation rate | Tokens |',
      '|---|---:|---:|---:|---:|']
    for s in summary: report.append(f'| {s["condition"]} | {s["success_rate"]:.3f} | {s["supported_success_rate"]:.3f} | {s["violation_rate"]:.3f} | {s["total_tokens"]} |')
    report += ['', 'Support is independently computed from available evidence, under declared source/freshness assumptions. It is not citation entailment or proof of factual truth.',
       'Intervals resample paired scenarios within case strata after averaging repeated calls. Pilot intervals are suppressed with fewer than two scenarios per case.',
       'Intervals are exploratory marginal 95% intervals, not multiplicity-adjusted significance tests. Predeclare primary comparisons.',
       'Zero observed violations is not a guarantee. Synthetic generator, fixed source policy and easy perception limit generalisation.',
       'Total token accounting includes failed episodes. Zero-call budget failures cannot be claimed as efficiency gains.',
       'API time excludes local computation; costs use configured rates. Resume replay is not a new repetition.',
       'v0.3 results are preliminary development evidence and are not pooled with this dataset.']
    (root/'REPORT.md').write_text('\n'.join(report))
    if summary: plot(root,summary,complete)
    return {'complete':complete,'episodes':len(rows),'planned':len(lock['jobs']),'accounting':account}

def plot(root,summary,complete):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    labels=[s['condition'] for s in summary]; x=np.arange(len(labels))
    axes[0].bar(x-.18,[s['success_rate'] for s in summary],.36,label='Physical success')
    axes[0].bar(x+.18,[s['supported_success_rate'] for s in summary],.36,label='Evidence-supported success')
    axes[0].set_ylim(0,1.05); axes[0].legend(fontsize=8); axes[0].set_ylabel('Episode fraction')
    axes[1].bar(x,[s['mean_tokens'] for s in summary],color='#167d9a'); axes[1].set_ylabel('Mean API tokens per completed episode')
    for a in axes: a.set_xticks(x,labels,rotation=40,ha='right'); a.tick_params(labelsize=8)
    fig.suptitle('Descriptive results — '+('complete run' if complete else 'PARTIAL RUN — not comparable'))
    fig.savefig(root/'results.png',dpi=180); fig.savefig(root/'results.pdf'); plt.close(fig)
