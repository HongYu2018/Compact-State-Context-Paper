"""Small actual learned encoder. Temperature fitted on separate calibration images."""
import time
import json
import hashlib
from pathlib import Path
import numpy as np
import torch
from torch import nn
from world import camera

LABELS=['red','blue','unknown']
def tensor(im): return torch.from_numpy(np.asarray(im).copy()).permute(2,0,1).float()/255
def model():
    return nn.Sequential(nn.Conv2d(3,8,5,stride=2),nn.ReLU(),nn.Conv2d(8,16,3,stride=2),
        nn.ReLU(),nn.AdaptiveAvgPool2d(1),nn.Flatten(),nn.Linear(16,3))
def samples(n,offset):
    return (torch.stack([tensor(camera(LABELS[i%2],offset+i,i%3==2)) for i in range(n)]),
            torch.tensor([2 if i%3==2 else i%2 for i in range(n)]))
def stats(logits,y,temp):
    p=(logits/temp).softmax(-1); scores,preds=p.max(-1); correct=preds.eq(y)
    ece=0.
    for i in range(10):
        lo=i/10; hi=(i+1)/10
        mask=(scores>=lo)&((scores<=hi) if i==9 else (scores<hi))
        if mask.any(): ece+=float(mask.float().mean()*abs(scores[mask].mean()-correct[mask].float().mean()))
    return dict(accuracy=float(correct.float().mean()),nll=float(nn.functional.cross_entropy(logits/temp,y)),
                ece_10_bins=ece,accepted_fraction=float(((scores>=.85)&(preds!=2)).float().mean()))
def train(path,epochs=12):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    torch.manual_seed(17); torch.set_num_threads(2)
    net=model(); x,y=samples(900,40000); start=time.perf_counter()
    loader=torch.utils.data.DataLoader(torch.utils.data.TensorDataset(x,y),batch_size=64,shuffle=True)
    opt=torch.optim.Adam(net.parameters(),lr=.003)
    for epoch in range(epochs):
        net.train()
        for a,b in loader:
            opt.zero_grad(); loss=nn.functional.cross_entropy(net(a),b); loss.backward(); opt.step()
        print(f'Vision epoch {epoch+1}/{epochs}: loss {loss.item():.4f}')
    net.eval()
    with torch.no_grad():
        cx,cy=samples(300,50000); logits=net(cx)
        grid=torch.logspace(-1,1,41)
        temp=float(min(grid,key=lambda t:float(nn.functional.cross_entropy(logits/t,cy))))
        tx,ty=samples(300,60000); test=net(tx)
    torch.save({'weights':net.state_dict(),'temperature':temp},path)
    result={'train_seeds':'40000:40899','calibration_seeds':'50000:50299','diagnostic_seeds':'60000:60299',
        'epochs':epochs,'temperature':temp,'seconds':time.perf_counter()-start,
        'calibration':stats(logits,cy,temp),'diagnostic':stats(test,ty,temp),
        'scope':'synthetic in-distribution calibration only; no general probability guarantee',
        'torch':torch.__version__}
    Path(str(path)+'.json').write_text(json.dumps(result,indent=2)); return result

class Encoder:
    def __init__(self,path):
        ckpt=torch.load(path,map_location='cpu',weights_only=True)
        self.net=model(); self.net.load_state_dict(ckpt['weights']); self.net.eval()
        self.temperature=ckpt['temperature']; self.model_hash=hashlib.sha256(Path(path).read_bytes()).hexdigest()
    def __call__(self,im):
        with torch.inference_mode():
            z=self.net[:-1](tensor(im).unsqueeze(0)); p=(self.net[-1](z)/self.temperature).softmax(-1)[0]
        i=int(p.argmax())
        return dict(label=LABELS[i],confidence=float(p[i]),latent=z[0].tolist())
