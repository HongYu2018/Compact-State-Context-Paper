import json, time, hashlib
from pathlib import Path
from context import pack as canonical, hashof as digest

def save_json(path,value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp"); tmp.write_text(json.dumps(value,indent=2)); tmp.replace(path)

class StopRun(RuntimeError):
    pass

class API:
    def __init__(self, client, root, cfg):
        self.client, self.root, self.cfg = client, Path(root), cfg
        self.root.mkdir(parents=True,exist_ok=True)

    def call(self, body, identity):
        key = digest([identity,body]); path = self.root / (key+'.json')
        if path.exists():
            saved = json.loads(path.read_text())
            if saved['status']=='pending':
                raise StopRun('Uncertain interrupted request. Inspect cache; do not automatically resend. See README.')
            return saved
        ledger = [json.loads(p.read_text()) for p in self.root.glob('*.json')]
        if any(x['status']=='pending' for x in ledger):
            raise StopRun('An unresolved request exists. See README recovery instructions.')
        if len(ledger) >= self.cfg['max_calls']:
            raise StopRun('API call limit reached; partial results saved.')
        spent = sum(x.get('estimated_usd',0) for x in ledger)
        # Conservative heuristic reservation, NOT an enforceable provider billing limit.
        reserve = ((len(canonical(body).encode())+10000)*self.cfg['input_per_million']
                   +self.cfg['max_output_tokens']*self.cfg['output_per_million'])/1e6
        if spent + reserve > self.cfg['budget_usd']:
            raise StopRun('Estimated spending guard reached; partial results saved.')
        save_json(path, {'status':'pending','identity':identity,'request_hash':key})
        start = time.perf_counter()
        try:
            response = self.client.responses.create(**body)
        except Exception as exc:
            raise StopRun(f'API request stopped ({type(exc).__name__}); pending record preserved. See README.') from None
        raw = response.model_dump(mode='json')
        usage = raw.get('usage') or {}
        inp, out = usage.get('input_tokens',0), usage.get('output_tokens',0)
        cached = (usage.get('input_tokens_details') or {}).get('cached_tokens',0)
        cost = ((inp-cached)*self.cfg['input_per_million']+cached*self.cfg['cached_per_million']
                +out*self.cfg['output_per_million'])/1e6
        saved = {'status':'complete','identity':identity,'request_hash':key,
            'raw_response':raw,'output_text':response.output_text,'latency_s':time.perf_counter()-start,
            'input_tokens':inp,'output_tokens':out,'cached_input_tokens':cached,'estimated_usd':cost}
        save_json(path,saved)
        return saved

