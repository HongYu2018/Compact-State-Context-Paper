"""Persistent evidence state and task-dependency context compiler. No hidden-world access."""
import hashlib
import json
from dataclasses import dataclass, asdict

def pack(x): return json.dumps(x,sort_keys=True,separators=(',',':'))
def hashof(x): return hashlib.sha256(pack(x).encode()).hexdigest()

@dataclass
class Capsule:
    id: str
    entity: str
    predicate: str
    value: object
    time: int
    source: str
    modality: str
    confidence: float = 1.0
    ttl: int = 3
    permission: str = 'agent'
    raw_ref: str = ''
    latent_ref: str = ''
    uncertainty: float = 0.0
    predecessors: tuple = ()

class State:
    def __init__(self):
        self.cold = {}                 # Immutable capsules; persisted in episode checkpoint.
        self.index = {}                # Typed graph claim edges indexed by entity/predicate.
        self.latents = {}              # Z: learned image features, not serialized to LLM.
        self.warm = []                 # Recent own actions and tool results, not oracle plans.
        self.invalidated = {}          # Explicit intervention -> predicate invalidation.
        self.goal = None
        self.goal_time = -1
        self.goal_id = None
        self.now = 0
        self.updates = 0

    def ingest(self, capsules, now, latents=None):
        self.now = now
        for c in capsules:
            if c.id in self.cold:
                if asdict(c) != self.cold[c.id]: raise ValueError('Evidence ID collision')
                continue
            self.cold[c.id] = asdict(c)
            self.index.setdefault(c.entity+':'+c.predicate, []).append(c.id)
            self.updates += 1
            if c.permission != 'agent': continue
            if c.predicate=='goal' and c.time>=self.goal_time:
                self.goal,self.goal_time,self.goal_id=c.value,c.time,c.id
            if c.predicate=='payload_changed':
                self.invalidated[c.entity+':mass'] = max(c.time,self.invalidated.get(c.entity+':mass',-1))
        if latents: self.latents.update(latents)

    def remember(self, action, outcome):
        self.warm.append({'time':self.now,'action':{k:action[k] for k in ['type','slot']},'outcome':outcome})
        self.warm = self.warm[-3:]

    def belief(self, entity, predicate, temporal=True, conflict=True):
        records=[self.cold[i] for i in self.index.get(entity+':'+predicate,[])
                 if self.cold[i]['permission']=='agent']
        # Latest reading from EACH source, not last-write-wins across conflicting sources.
        latest={}
        for r in sorted(records,key=lambda r:(r['time'],r['id'])): latest[r['source']]=r
        fresh=[r for r in latest.values() if not temporal or
               (r['time']<=self.now and self.now-r['time']<=r['ttl'] and
                r['time']>self.invalidated.get(entity+':'+predicate,-1))]
        base={'entity':entity,'predicate':predicate,'status':'missing','value':None,
              'evidence':[],'alternatives':[]}
        if not fresh:
            base['status']='stale' if records else 'missing'
            base['evidence']=[r['id'] for r in latest.values()]
            return base
        # A new calibrated scale intervention supersedes prior estimates only at its time.
        authoritative=[r for r in fresh if r['source']=='tool_scale']
        if authoritative:
            newest=max(authoritative,key=lambda r:r['time'])
            fresh=[r for r in fresh if r['time']>=newest['time']]
        base['evidence']=[r['id'] for r in fresh]
        base['alternatives']=[{'value':r['value'],'score':r['confidence'],'source':r['source']} for r in fresh]
        values={pack(r['value']) for r in fresh}
        if conflict and len(values)>1:
            base['status']='conflict'; return base
        chosen=max(fresh,key=lambda r:(r['time'],r['confidence']))
        base.update(value=chosen['value'],age=self.now-chosen['time'],
                    score=chosen['confidence'],uncertainty=chosen['uncertainty'])
        base['status']='known'
        if chosen['confidence']<.85 or chosen['value']=='unknown': base['status']='uncertain'
        return base

    def facts(self, temporal=True, conflict=True):
        result={}
        for i in [0,1]:
            for prop in ['color','mass']:
                result[f'slot{i}:{prop}']=self.belief(f'slot{i}',prop,temporal,conflict)
        for i in [0,1]:
            m=result[f'slot{i}:mass']
            status='unknown'
            if m['status']=='known':
                lo,hi=m['value']-m['uncertainty'],m['value']+m['uncertainty']
                status='within' if hi<=3 else ('over' if lo>3 else 'boundary_uncertain')
            result[f'slot{i}:capacity']={'entity':f'slot{i}','predicate':'capacity',
                'value':status,'evidence':m['evidence'],'rule':'mass_interval_vs_3kg'}
        return result

    def snapshot(self):
        return dict(G={'claims':self.cold,'index':self.index},Z=self.latents,
            B=self.facts(),T={'now':self.now,'invalidated':self.invalidated},
            P={'goal':self.goal,'goal_evidence':self.goal_id},warm=self.warm,updates=self.updates)

RULES={'capacity_kg':3,'measurement_max_age':3,'freshness':'age <= 3 AND after payload-change event',
       'capacity_scope':'one target object only','uncertain':'acquire evidence before committing',
       'tool_effects':{'inspect':'reveals cameras; does not measure mass',
                      'weigh':'fresh authoritative scale measurement for selected slot',
                      'disclose':'show raw camera evidence; does not update its capture time'}}

def compile_context(state, mode, budget, count, temporal=True, conflict=True):
    base={'now':state.now,'task':state.goal,'task_evidence':state.goal_id,'rules':RULES,
          'recent_actions':state.warm}
    facts=state.facts(temporal,conflict)
    if mode=='full_history':
        base['evidence']=[r for r in state.cold.values() if r['permission']=='agent']
        required=[]
    elif mode=='full_state':
        required=sorted(facts); base['facts']={k:facts[k] for k in required}
    else:
        # Resolve identity first; only THEN select the target's mass dependencies.
        colors=[f'slot{i}:color' for i in [0,1]]
        matches=[i for i in [0,1] if facts[colors[i]]['status']=='known' and
                 facts[colors[i]]['value']==state.goal]
        if len(matches)==1 and all(facts[k]['status']=='known' for k in colors):
            i=matches[0]; required=colors+[f'slot{i}:mass',f'slot{i}:capacity']
        else: required=colors
        base['facts']={k:facts[k] for k in required}
    base['evidence_access']='Use disclose(slot) for a raw camera image; inspect for occlusion; weigh for missing/conflicting/stale mass.'
    tokens=count(pack(base))
    # Never silently drop safety facts. Over-budget projection is explicitly refused.
    overflow = mode=='capsule' and tokens>budget
    audit={'selected_keys':required,'tokens':tokens,'budget':budget,'overflow':overflow,
           'minimality_scope':'dependency-closed projection for fixed two-slot task, NOT global optimality',
           'retained_claim_ids':sorted({x for f in base.get('facts',{}).values() for x in f['evidence']})}
    return base,audit

def verify(state, action):
    """Independent verifier: public belief state only, never hidden simulator state."""
    typ,slot=action['type'],action['slot']
    if typ not in ['move','defer']: return True,'information action or abstention'
    facts=state.facts(); color=facts[f'slot{slot}:color']; mass=facts[f'slot{slot}:mass']
    if color['status']!='known' or color['value']!=state.goal: return False,'target identity unresolved or wrong'
    if mass['status']!='known': return False,'mass '+mass['status']
    cap=facts[f'slot{slot}:capacity']['value']
    if typ=='move' and cap!='within': return False,'capacity not proven within limit'
    if typ=='defer' and cap!='over': return False,'overload not established'
    return True,'supported by current evidence'
