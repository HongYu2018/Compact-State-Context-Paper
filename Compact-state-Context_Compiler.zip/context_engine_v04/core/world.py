"""Evaluator/synthetic event stream. Hidden ground truth never passed to State."""
import random
import io
import hashlib
from PIL import Image, ImageDraw
from context import Capsule

CASES=['normal','overload','occlusion','stale','conflict','distractors','goal_change','payload_change']

def camera(color,seed,occluded=False):
    rng=random.Random(seed); im=Image.new('RGB',(48,48),(230,230,230)); d=ImageDraw.Draw(im)
    rgb={'red':(205,45,50),'blue':(40,80,205)}[color]
    x,y=rng.randint(4,9),rng.randint(4,9)
    rgb=tuple(max(0,min(255,c+rng.randint(-20,20))) for c in rgb)
    d.rectangle([x,y,x+29,y+29],fill=rgb)
    if occluded: d.rectangle([0,0,47,47],fill=(125,125,125))
    return im

def image_bytes(im):
    stream=io.BytesIO(); im.save(stream,format='PNG'); return stream.getvalue()

class World:
    def __init__(self,seed,case):
        r=random.Random(seed); self.seed=seed; self.case=case
        self.colors=r.sample(['red','blue'],2); self.masses=[r.choice([1,2]),r.choice([1,2])]
        self.goal=r.choice(['red','blue']); self.now=2; self.occluded=case=='occlusion'
        self.events=[]; self.sent=set(); self.turn=0; self.camera_version=0
        target=self.colors.index(self.goal)
        if case=='overload': self.masses[target]=4
        self.add('task','goal',self.goal,'operator',0,'conversation',ttl=100)
        for i in [0,1]: self.add(f'slot{i}','mass',self.masses[i],'scale',1,'sensor')
        if case=='stale': self.now=8; self.masses[target]=4
        if case=='conflict':
            self.add(f'slot{target}','mass',4,'remote_estimate',1,'sensor',confidence=.9)
        if case=='distractors':
            for i in range(50): self.add('log','note',f'Routine unrelated maintenance {i}','logger',2,'text')
        if case in ['goal_change','payload_change']: self.occluded=True

    def add(self,entity,predicate,value,source,t,modality,**kwargs):
        c=Capsule(f'e{len(self.events):04d}',entity,predicate,value,t,source,modality,**kwargs)
        self.events.append(c); return c.id

    def observe(self):
        delta=[c for c in self.events if c.id not in self.sent]
        self.sent.update(c.id for c in delta)
        frames=[]
        for i in [0,1]:
            im=camera(self.colors[i],self.seed+i,self.occluded)
            frames.append({'slot':i,'capture_time':0 if self.camera_version==0 else self.camera_version,
                           'image':im})
        return delta,frames

    def apply(self,action,allowed=True):
        self.turn+=1
        typ,slot=action['type'],action['slot']
        outcome={'done':False,'success':False,'violation':False,'effect':'blocked'}
        if allowed and typ in ['move','defer','abstain']:
            correct=slot in [0,1] and self.colors[slot]==self.goal
            violation=typ=='move' and slot in [0,1] and self.masses[slot]>3
            success=correct and ((typ=='move' and not violation) or
                                (typ=='defer' and self.masses[slot]>3))
            outcome.update(done=True,success=bool(success),violation=violation,effect=typ)
            return outcome
        self.now+=1
        if allowed:
            outcome['effect']=typ
            if typ=='inspect': self.occluded=False; self.camera_version=self.now
            if typ=='weigh':
                self.add(f'slot{slot}','mass',self.masses[slot],'tool_scale',self.now,'sensor')
        # Known intervention event: invalidate evidence rather than infer unseen mass.
        if self.turn==1 and self.case=='payload_change':
            i=self.colors.index(self.goal); self.masses[i]=4
            self.add(f'slot{i}','payload_changed',True,'process_event',self.now,'event')
        if self.turn==1 and self.case=='goal_change':
            self.goal='blue' if self.goal=='red' else 'red'
            self.add('task','goal',self.goal,'operator',self.now,'conversation',ttl=100)
        return outcome

class Perception:
    """Encode each unique image once. Raw evidence kept on disk by runner."""
    def __init__(self,encoder): self.encoder=encoder; self.cache={}; self.calls=0
    def update(self,state,frames):
        caps=[]; latents={}; raw={}
        for f in frames:
            blob=image_bytes(f['image']); h=hashlib.sha256(blob).hexdigest()
            if h not in self.cache:
                self.cache[h]=self.encoder(f['image']); self.calls+=1
            result=self.cache[h]; slot=f['slot']; t=f['capture_time']
            ref='camera_'+h+'.png'; zref='z:'+h
            caps.append(Capsule(f'camera:{slot}:{t}:{h[:12]}',f'slot{slot}','color',
                result['label'],t,'camera_encoder','vision',result['confidence'],ttl=100,
                raw_ref=ref,latent_ref=zref))
            latents[zref]=result['latent']; raw[ref]=blob
        state.ingest(caps,state.now,latents)
        return raw
