import json
import tempfile
import unittest
from pathlib import Path
from context import *
from world import World,Perception
from runner import run,config,body_for
from transport import API,StopRun,save_json

def cap(i,entity='slot0',prop='mass',value=2,t=1,source='scale',**kw):
    return Capsule(i,entity,prop,value,t,source,'sensor',**kw)
def prepared():
    s=State(); s.ingest([cap('g','task','goal','red',ttl=100),
      cap('c0',prop='color',value='red',ttl=100),cap('c1','slot1','color','blue',ttl=100),
      cap('m0'),cap('m1','slot1',value=4)],2); return s

class FakeEncoder:
    """Plumbing test ONLY: pixel heuristic, not the experimental neural encoder."""
    model_hash='offline_fake_encoder'
    def __call__(self,im):
        r,g,b=im.getpixel((20,20)); label='unknown' if r==b else ('red' if r>b else 'blue')
        return dict(label=label,confidence=.99,latent=[r/255,g/255,b/255])

class FakeResponse:
    def __init__(self,action): self.output_text=json.dumps(action)
    def model_dump(self,**kwargs):
        return dict(status='completed',model='MOCK',usage={'input_tokens':100,'output_tokens':30})

class FakeClient:
    def __init__(self,action=None): self.responses=self; self.calls=0; self.action=action
    def create(self,**body):
        self.calls+=1
        a=self.action or dict(type='abstain',slot=-1,reason='offline plumbing test',evidence=[])
        return FakeResponse(a)

class Tests(unittest.TestCase):
    def test_delta_dedup_and_collision(self):
        s=State(); c=cap('a'); s.ingest([c],2); s.ingest([c],3)
        self.assertEqual(s.updates,1)
        with self.assertRaises(ValueError): s.ingest([cap('a',value=4)],3)

    def test_conflict_retained_then_resolved(self):
        s=prepared(); s.ingest([cap('other',value=4,source='remote')],2)
        self.assertEqual(s.belief('slot0','mass')['status'],'conflict')
        self.assertEqual(len(s.belief('slot0','mass')['alternatives']),2)
        s.ingest([cap('new',value=2,t=3,source='tool_scale')],3)
        self.assertEqual(s.belief('slot0','mass')['value'],2)

    def test_freshness_boundary_and_invalidation(self):
        s=prepared(); s.ingest([],4)
        self.assertEqual(s.belief('slot0','mass')['status'],'known')
        s.ingest([],5); self.assertEqual(s.belief('slot0','mass')['status'],'stale')
        s.ingest([cap('change',prop='payload_changed',value=True,t=5)],5)
        s.ingest([cap('new',t=6,source='tool_scale')],6)
        self.assertEqual(s.belief('slot0','mass')['status'],'known')

    def test_no_hidden_private_claim(self):
        s=prepared(); s.ingest([cap('private',value=10,t=2,permission='private')],2)
        self.assertEqual(s.belief('slot0','mass')['value'],2)
        p,_=compile_context(s,'full_history',99999,len)
        self.assertNotIn('private',pack(p))

    def test_task_projection_switches_target(self):
        s=prepared(); p,a=compile_context(s,'capsule',99999,len)
        self.assertIn('slot0:mass',p['facts']); self.assertNotIn('slot1:mass',p['facts'])
        s.ingest([cap('goal2','task','goal','blue',t=2,source='operator',ttl=100)],2)
        p,a=compile_context(s,'capsule',99999,len)
        self.assertIn('slot1:mass',p['facts']); self.assertNotIn('slot0:mass',p['facts'])

    def test_uncertain_identity_preserves_alternatives(self):
        s=prepared(); s.ingest([cap('newcolor',prop='color',value='unknown',t=2,ttl=100)],2)
        p,a=compile_context(s,'capsule',99999,len)
        self.assertEqual(set(p['facts']),{'slot0:color','slot1:color'})
        self.assertFalse(verify(s,{'type':'move','slot':0})[0])

    def test_budget_refuses_not_truncates(self):
        s=prepared(); p,a=compile_context(s,'capsule',1,len)
        self.assertTrue(a['overflow']); self.assertIn('rules',p); self.assertIn('slot0:mass',p['facts'])

    def test_verifier_arithmetic_and_uncertainty(self):
        s=prepared(); self.assertTrue(verify(s,{'type':'move','slot':0})[0])
        self.assertFalse(verify(s,{'type':'defer','slot':0})[0])
        s.ingest([cap('new',value=2.9,t=2,source='tool_scale',uncertainty=.2)],2)
        self.assertFalse(verify(s,{'type':'move','slot':0})[0])

    def test_latent_cache_and_raw_pointer(self):
        w=World(30000,'normal'); s=State(); delta,frames=w.observe(); s.ingest(delta,w.now)
        p=Perception(FakeEncoder()); raw=p.update(s,frames); n=p.calls; p.update(s,frames)
        self.assertEqual(n,p.calls); self.assertTrue(s.latents)
        for c in s.cold.values():
            if c['modality']=='vision': self.assertIn(c['raw_ref'],raw)

    def test_dynamic_event_and_no_sensor_leak(self):
        w=World(30007,'payload_change'); delta,frames=w.observe()
        self.assertTrue(all(c.predicate!='color' for c in delta))
        w.apply({'type':'inspect','slot':-1}); delta,_=w.observe()
        self.assertEqual([c.predicate for c in delta],['payload_changed'])

    def test_real_action_schema_and_disclosure(self):
        body=body_for(config(),{'x':1},b'test')
        self.assertEqual(body['input'][0]['content'][1]['type'],'input_image')
        self.assertTrue(body['text']['format']['strict'])

    def test_sdk_serialization_with_mock_http(self):
        import httpx
        from openai import OpenAI
        def respond(request):
            data=json.loads(request.content)
            self.assertEqual(data['text']['format']['type'],'json_schema')
            self.assertFalse(data['store'])
            output=json.dumps(dict(type='abstain',slot=-1,reason='mock',evidence=[]))
            return httpx.Response(200,json={'id':'resp_mock','object':'response','created_at':0,
                'model':config()['model'],'status':'completed','output':[{'id':'msg_mock',
                'type':'message','role':'assistant','status':'completed','content':[
                    {'type':'output_text','text':output,'annotations':[]}]}],
                'usage':{'input_tokens':100,'output_tokens':30,'total_tokens':130}})
        with tempfile.TemporaryDirectory() as d:
            with OpenAI(api_key='offline-test-placeholder',max_retries=0,
                 http_client=httpx.Client(transport=httpx.MockTransport(respond))) as client:
                result=API(client,d,config()).call(body_for(config(),{'task':'red'}),'sdk_test')
            self.assertEqual(json.loads(result['output_text'])['type'],'abstain')

    def test_api_cache_pending_and_budget(self):
        with tempfile.TemporaryDirectory() as d:
            cfg=config(); cfg['max_calls']=1; c=FakeClient(); api=API(c,d,cfg)
            api.call({},0); api.call({},0); self.assertEqual(c.calls,1)
            with self.assertRaises(StopRun): api.call({},1)
        with tempfile.TemporaryDirectory() as d:
            cfg=config(); cfg['budget_usd']=0
            with self.assertRaises(StopRun): API(FakeClient(),d,cfg).call({},0)
            save_json(Path(d)/'pending.json',{'status':'pending'})
            cfg['budget_usd']=1
            with self.assertRaises(StopRun): API(FakeClient(),d,cfg).call({},0)

    def test_end_to_end_resume_and_no_action_replacement(self):
        with tempfile.TemporaryDirectory() as d:
            cfg=config(); cfg['episodes']=1; c=FakeClient()
            run(d,cfg,c,FakeEncoder(),lambda s:len(s)//4)
            for p in (Path(d)/'episodes').glob('*.json'):
                e=json.loads(p.read_text()); self.assertFalse(e['success'])
                self.assertEqual(e['trace'][0]['action']['type'],'abstain')
                self.assertIn('Z',e['state'])
            calls=c.calls; run(d,cfg,c,FakeEncoder(),lambda s:len(s)//4)
            self.assertEqual(c.calls,calls)
            cfg['seed']+=1
            with self.assertRaises(ValueError): run(d,cfg,c,FakeEncoder(),len)

    def test_guard_blocks_without_substitution(self):
        with tempfile.TemporaryDirectory() as d:
            cfg=config(); cfg.update(episodes=2,methods=['capsule_verified'],max_steps=2)
            c=FakeClient(dict(type='move',slot=0,reason='deliberately bad test action',evidence=[]))
            run(d,cfg,c,FakeEncoder(),lambda s:len(s)//4)
            for p in (Path(d)/'episodes').glob('*.json'):
                for t in json.loads(p.read_text())['trace']:
                    if t['blocked']:
                        self.assertEqual(t['action']['type'],'move')
                        self.assertEqual(t['outcome']['effect'],'blocked')

if __name__=='__main__': unittest.main()
