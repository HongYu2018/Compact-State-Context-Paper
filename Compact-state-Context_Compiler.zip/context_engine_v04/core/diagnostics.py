"""Deterministic reference-policy diagnostics, NOT LLM performance evaluation."""
import json
import time
from pathlib import Path
from context import State,compile_context,verify
from world import World,Perception,CASES

def reference_action(payload):
    facts=payload['facts']; goal=payload['task']
    color=[facts[f'slot{i}:color'] for i in [0,1]]
    if any(c['status']!='known' for c in color):
        return {'type':'inspect','slot':-1}
    targets=[i for i,c in enumerate(color) if c['value']==goal]
    if len(targets)!=1: return {'type':'abstain','slot':-1}
    slot=targets[0]; mass=facts.get(f'slot{slot}:mass')
    if not mass or mass['status']!='known': return {'type':'weigh','slot':slot}
    capacity=facts.get(f'slot{slot}:capacity',{}).get('value')
    if capacity=='within': return {'type':'move','slot':slot}
    if capacity=='over': return {'type':'defer','slot':slot}
    return {'type':'weigh','slot':slot}

def diagnose(encoder,count,out,n=80):
    perception=Perception(encoder); records=[]; start=time.perf_counter()
    for i in range(n):
        # Development seeds distinct from live LLM test seeds.
        world=World(20000+i,CASES[i%len(CASES)]); state=State(); success=False; trace=[]
        for step in range(6):
            delta,frames=world.observe(); state.ingest(delta,world.now); perception.update(state,frames)
            full,_=compile_context(state,'full_state',100000,count)
            capsule,audit=compile_context(state,'capsule',850,count)
            a=reference_action(full); b=reference_action(capsule)
            allowed,reason=verify(state,b)
            trace.append(dict(actions_agree=a==b,capsule_tokens=audit['tokens'],overflow=audit['overflow'],action=b))
            outcome=world.apply(b,allowed)
            state.remember(b,{'effect':outcome['effect'],'verification':reason})
            if outcome['done']: success=outcome['success']; break
        records.append(dict(case=world.case,seed=world.seed,success=success,trace=trace))
    result={'label':'RULE REFERENCE + NEURAL VISION: NOT LLM RESULTS','episodes':n,
       'successes':sum(r['success'] for r in records),'projection_action_agreement':
       all(t['actions_agree'] for r in records for t in r['trace']),
       'budget_overflows':sum(t['overflow'] for r in records for t in r['trace']),
       'max_capsule_tokens':max(t['capsule_tokens'] for r in records for t in r['trace']),
       'unique_image_encodes':perception.calls,'seconds':time.perf_counter()-start,'records':records}
    Path(out).parent.mkdir(parents=True,exist_ok=True); Path(out).write_text(json.dumps(result,indent=2))
    return {k:v for k,v in result.items() if k!='records'}
