# First-paper experimental package v0.4

This release freezes the v0.3 context/perception/world algorithms and adds a reproducible experiment harness. It implements the agreed next stage: repeated trials, fresh balanced scenarios, independent evidence-support scoring, ablations, budget sweeps, paired statistics and report figures. It is not a declaration of publication readiness.

## Colab start
1. Unzip and upload `First_Paper_Experiments_v04.ipynb` to Colab.
2. Run cells in order. Upload the ORIGINAL v0.4 ZIP when asked. CPU is sufficient.
3. Keep Drive enabled. Use `paper_v04_pilot_01`, never a v0.3 folder.
4. Run the offline tests. The pretrained visual encoder is bundled; no training is required.
5. Keep STAGE='pilot' and SWEEP=False for the first API run. It schedules 112 episodes (8 scenarios × 7 conditions × 2 independent repetitions), at most 672 requests. The default estimated spending guard is $5; this is not an expected charge or a guaranteed provider billing cap.
6. In Colab Secrets add OPENAI_API_KEY, paste the key into Value, and enable Notebook access. Do not paste the key into code or chat.
7. Review the printed protocol and set RUN_API=True only when ready for paid calls.
8. Download the results ZIP, which contains audit tables, reports, PNG/PDF figures, responses and checkpoints. Share this ZIP for analysis.

## What changed, and what did not
The G/Z/B/T/P state, neural encoder, source-resolution rules, task projection, verifier and two-slot simulator are copied from v0.3. The core runner has three instrumentation changes only: an explicit case argument for one-scenario jobs, a shared API ledger, and unique job identity in cache keys. Model prompt and neural weights are unchanged. Compiler innovation, larger task families and additional modalities remain separate work; this experiment establishes whether the existing method merits those extensions.

The previous uploaded v0.3 results are preserved under `precheck/` with their original file checksum and an extracted summary. They are preliminary DEVELOPMENT evidence. Do not pool them with v0.4 test results or describe v0.3/v0.4 differences as a matched algorithm comparison: sampled scenarios and repetitions differ.

## Schedules
| Stage | Scenarios | Repeats | Main conditions | Episodes | Maximum calls |
|---|---:|---:|---:|---:|---:|
| pilot | 8 | 2 | 7 | 112 | 672 |
| development | 80 | 3 | 7 | 1,680 | 10,080 |
| test | 400 | 3 | 7 | 8,400 | 50,400 |

Each case receives equal scenario counts. Fresh ranges: pilot 80000–80007; development 81000–81079; test 90000–90399. Repetitions replay the SAME scenario seeds with separate API calls and independent cache identities. Temperature zero is not a determinism guarantee. Method order and scenario order are shuffled reproducibly per repetition. The first pilot has only one scenario per case; bootstrap intervals are intentionally suppressed.

Main conditions: full_history, full_state, capsule, full_state_verified, capsule_verified, capsule_no_temporal, capsule_no_conflict. The primary comparison is unguarded full_state versus capsule. Verified counterparts are secondary. Ablations remove temporal/conflict treatment during compilation only. No claim that these are state-of-the-art RAG baselines: embedding retrieval and published memory/compression baselines are still required for broad comparative claims.

SWEEP=True creates a separate experiment with full_state and unguarded capsule budgets 200, 300, 450, 650 and 850. Use a new RUN_NAME. The budget counts the compiled payload, not API instructions/schema/images. The frozen compiler refuses an insufficient budget; it does NOT adaptively optimise or truncate required facts. Zero-call budget failures remain failures. These sweeps measure feasibility thresholds and efficiency tradeoffs, not optimal compression. Baselines are uncapped reference conditions.

## Independent evidence-supported outcome
`evaluator.py` does not import the compiler, belief-updater or verifier. It reads the terminal evidence snapshot and independently checks visible source records, current goal, object identity, freshness, intervention invalidation, source conflicts, uncertainty and capacity. Physical success still comes from the simulator.

Evidence-supported success = physical success AND terminal commitment justified by the agent-accessible evidence pool. A physically correct action with unresolved sensor disagreement fails this criterion. The evaluator shares the declared domain assumptions, but not the implementation of agent inference. It is not independent human annotation, nor proof of source truth. It does not verify semantic entailment of the LLM's cited IDs or guarantee that every supporting record was included in the selected prompt. Those require separate audit metrics in a later release.

Only terminal executed commitments determine supported-success score. Original unsafe proposals, blocks and executed violations remain separate metrics. A blocked unsafe proposal followed by a justified deferral can achieve supported success. An abstention never completes this task. Snapshots are taken before new observations are ingested after an action, so the terminal snapshot contains no future evidence.

## Statistical protocol
Results contain episode-level audit data plus condition summaries. Report both physical success and evidence-supported success. Total-token/per-supported-success includes costs of failed episodes and is undefined when there are no supported successes.

For a COMPLETE run, paired differences are calculated for success, supported success, violations, tokens and API latency. Independent API repeats are averaged within each scenario/condition. A case-stratified cluster bootstrap resamples scenario IDs, preserving paired conditions and all repeats. It uses 2,000 draws and returns marginal 95% percentile intervals. At least two scenarios per case are required. Intervals are exploratory and not corrected for multiple comparisons. Primary comparisons must be declared before reading the test results. No superiority claim from an interval merely containing zero; any non-inferiority claim requires a justified, predeclared margin and analysis.

Partial runs receive descriptive summaries but NO comparative confidence intervals. Finish all scheduled jobs before interpreting condition differences. The plotted summaries are descriptive; paired uncertainty is in paired_intervals.csv. Repeated trials reduce API variability uncertainty; they do not create new independent physical scenarios. New generator seeds do not establish real-world generalisation.

## Accounting and resumption
The shared root api_cache enforces ONE call/spending ledger across all jobs. Requests reserve an estimated cost, log pending status before sending and disable automatic retries. Completed requests replay without charge on resume. An interrupted request may have unknown billing status and stops further requests. Inspect the API status/usage first; remove only a pending entry confirmed not charged. Do not delete complete caches. Run only one notebook against a results folder at a time.

The protocol lock stores scenario schedule, full code hashes and vision hash. Changing code, conditions, model, thresholds, budget or repetitions requires a NEW folder. The lock is a local reproducibility record, not a public preregistration. Default stage cost guards are $5/$20/$80; long runs may stop before completion. Estimate real usage from pilot traces before starting development/test. Do not extrapolate the cheap v0.3 run as a guaranteed large-run price.

Rates use the existing configured model snapshot and prices; verify provider rates before a paid run. Total API usage is provider-reported. Latency includes original API call duration, with local compilation/perception separately logged. Neural training cost is recorded in the bundled checkpoint metadata. Core per-job reports may omit shared-ledger totals; use the ROOT accounting.json and REPORT.md as authoritative experiment summaries.

## Publication boundaries
The first implementation tests context compilation on a fixed, deliberately simple workcell. It does not yet test repeated-colour identity tracking, variable capacity, general tasks, open-world belief learning, joint multimodal neural fusion, or real industrial data. More seeds alone cannot supply methodological novelty. The paper still needs a task-general compiler contribution, stronger baselines and broader validation before making broad claims. Preserve null/negative results and inspect failed cases rather than tuning on the frozen test split.
