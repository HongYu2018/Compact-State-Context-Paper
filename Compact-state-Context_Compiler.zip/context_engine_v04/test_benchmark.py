import unittest,tempfile,json
from pathlib import Path
from benchmark import protocol,schedule,prepare,run
from evaluator import supported,episode_audit
from analysis import paired_interval,analyse
from test_context import prepared,cap,FakeEncoder,FakeClient

class BenchTests(unittest.TestCase):
    def test_balanced_distinct_repetitions(self):
        p=protocol(); jobs=schedule(p)
        self.assertEqual(len(jobs),112)
        self.assertEqual(len(set(j['id'] for j in jobs)),112)
        self.assertEqual(jobs,schedule(p))
        for name in [x['name'] for x in p['conditions']]:
            self.assertEqual(len([j for j in jobs if j['name']==name]),16)

    def test_frozen_protocol(self):
        with tempfile.TemporaryDirectory() as d:
            p=protocol(); prepare(d,p,FakeEncoder()); prepare(d,p,FakeEncoder())
            p['repeats']=3
            with self.assertRaises(ValueError): prepare(d,p,FakeEncoder())

    def test_independent_audit_lucky_conflict(self):
        s=prepared(); s.ingest([cap('conflict',value=4,source='remote')],2)
        snap=s.snapshot(); a={'type':'move','slot':0}
        self.assertFalse(supported(snap,a)[0])
        e={'state':snap,'success':True,'trace':[{'action':a,'outcome':{'done':True}}]}
        self.assertFalse(episode_audit(e)['supported_success'])

    def test_independent_freshness_and_intervention(self):
        s=prepared(); a={'type':'move','slot':0}
        s.ingest([],4); self.assertTrue(supported(s.snapshot(),a)[0])
        s.ingest([],5); self.assertFalse(supported(s.snapshot(),a)[0])
        s.ingest([cap('tool',t=6,source='tool_scale')],6)
        self.assertTrue(supported(s.snapshot(),a)[0])
        s.ingest([cap('change',prop='payload_changed',value=True,t=6)],6)
        self.assertFalse(supported(s.snapshot(),a)[0])

    def test_bootstrap_pairs_clusters_and_pilot_guard(self):
        records=[]
        for case in ['a','b']:
            for scenario in range(3):
                for repeat in range(2):
                    for name,val in [('full',1),('compact',2)]:
                        records.append({'case':case,'scenario':scenario,'condition':name,'x':val})
        r=paired_interval(records,'full','compact','x',100)
        self.assertEqual(r['delta'],1); self.assertEqual(r['low'],1); self.assertEqual(r['n_scenarios'],6)
        tiny=[r for r in records if r['scenario']==0]
        self.assertEqual(paired_interval(tiny,'full','compact','x')['low'],'')

    def test_shared_call_cap_and_partial_reporting(self):
        with tempfile.TemporaryDirectory() as d:
            p=protocol(); p.update(n_scenarios=1,repeats=2,max_calls=1,
                 conditions=[{'name':'full_state','method':'full_state','budget':850}])
            c=FakeClient(); r=run(d,p,c,FakeEncoder(),lambda s:len(s)//4)
            self.assertEqual(c.calls,1); self.assertFalse(r['complete']); self.assertEqual(r['episodes'],1)
            r=run(d,p,c,FakeEncoder(),lambda s:len(s)//4)
            self.assertEqual(c.calls,1)
            self.assertFalse((Path(d)/'paired_intervals.csv').exists())

    def test_complete_repeats_are_new_calls_resume_is_not(self):
        with tempfile.TemporaryDirectory() as d:
            p=protocol(); p.update(n_scenarios=1,repeats=2,
                 conditions=[{'name':'full_state','method':'full_state','budget':850}])
            c=FakeClient(); result=run(d,p,c,FakeEncoder(),lambda s:len(s)//4)
            self.assertTrue(result['complete']); self.assertEqual(c.calls,2)
            run(d,p,c,FakeEncoder(),lambda s:len(s)//4); self.assertEqual(c.calls,2)
            self.assertEqual(len(list((Path(d)/'api_cache').glob('*.json'))),2)

if __name__=='__main__': unittest.main()
